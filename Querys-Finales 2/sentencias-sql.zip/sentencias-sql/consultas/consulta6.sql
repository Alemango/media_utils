SELECT
  cdCaso,
  numCuenta,
  tpTransaccion,
  -- CAMBIO AQUÍ: Se reemplaza NVL por COALESCE
  COALESCE((SELECT NB_PAIS FROM GORAPR.TSCA106_PAIS WHERE CD_PAIS_UIF = cdPaisDestino),cdPaisDestino) AS cdPaisDestino,
  cdParaisoFiscal,
  nivelRiesgo,
  -- CAMBIO AQUÍ: Se reemplaza NVL por COALESCE
  COALESCE(COUNT( cdReferencia ),0) numOperaciones,
  COALESCE(SUM( imInstrumento ),0) montoTransacciones,
  fhFolio
FROM
(
  SELECT 
    T13.CD_CASO AS cdCaso,
    T60.CD_REFERENCIA cdReferencia,
    T60.NU_CUENTA numCuenta,
    T60.FH_REPORTE fhReporte,
    T60.CD_ORG_REGULADOR orgRegulador,
    T60.CD_ENTIDAD cdEntidad,
    TO_CHAR( T60.FH_FOLIO, 'YYYY' ) fhFolio,
    CASE T60.TP_TRANSACC 
        WHEN 'R' THEN 'RECIBIDAS' 
        WHEN 'E' THEN 'ENVIADAS' 
    END AS tpTransaccion,
    T60.NB_CORRESPONSAL nbCorresponsal,
    T60.NB_ENTIDAD_ORIGEN nbEntidadOrigen,
    T60.NB_ENTIDAD_DESTINO nbEntidadDestino,
    T60.CD_BIC_ABA cdBicAba,
    T60.NB_OPER_ORIGEN nbOperOrigen,
    T60.NB_OPER_DESTINO nbOperDest,
    T60.CD_INSTRUMENTO cdInstrumento,
    T60.NU_CLIENTE nuCliente,
    T60.CD_MONEDA cdMoneda,
    T60.IM_INST_CAMBIO imInstrumento,
    T60.CD_PAIS_ORI cdPaisOrigen,
    T60.CD_PAIS_BENEF cdPaisDestino,
    T69.NB_NIVEL_RIESGO nivelRiesgo,
    T69.CD_PARAISO_FISC cdParaisoFiscal,
    T60.FH_PROCESO anioProceso
  FROM GORAPR.TSCA060_OPIS T60
  JOIN GORAPR.TSCA013_ALERTA T13
    ON T13.CD_CASO = T60.CD_CASO  AND T13.CD_CLIENTE = T60.NU_CLIENTE
  LEFT JOIN GORAPR.TSCA069_RIESGO_PAIS T69
    ON T60.CD_PAIS_BENEF = T69.CD_ISO    
  WHERE
    T13.CD_CASO IN (&CD_CASO_LIST)
    AND T13.CD_SISTEMA IN (&CD_SISTEMA_LIST)
    AND T13.CD_ALERTA IN (&CD_ALERTA_LIST)
) AS subconsulta
GROUP BY cdCaso,numCuenta,tpTransaccion,nivelRiesgo,cdParaisoFiscal,cdPaisDestino,fhFolio
ORDER BY fhFolio asc;

--TSCA060_OPIS
--TSCA013_ALERTA
--TSCA069_RIESGO_PAIS
--TSCA106_PAIS