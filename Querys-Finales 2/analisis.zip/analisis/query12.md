Let's analyze this final SQL query for you. It's a comprehensive one that uses a `UNION` to combine data from two different movement tables (`TSCA019_MOV_BG` for general banking and `TSCA059_MOV_TC` for credit card movements), and includes complex subqueries for calculations and lookups.

---

### Tablas de Entrada

This query retrieves information from the following tables:

**For the first `SELECT` statement (general banking movements, aliased as `MVBG`):**

* **`GORAPR.TSCA019_MOV_BG` (aliased as `MVBG`)**: This is the primary source for general banking movement data.
* **`GORAPR.TSCA051_ACT_BANXICO` (aliased as `BANX`)**: Left-joined with `MVBG` to get the Banxico activity name (`NB_ACT_BANXICO`).
* **`GORAPR.TSCA108_CAT_OPER`**: Used in a subquery to translate the `CD_LEYENDA` (operation code) into a human-readable concept (`nbConceptoTC`).
* **`GORAPR.TSCA003_OFICINA`**: Used in subqueries to get the office name (`NB_OFICINA`) based on `CD_OFICINA` for `nbOficina` and `cdCentro`.
* **`GORAPR.TSCA013_ALERTA`**: Used extensively in subqueries within the `WHERE` clause and for calculating `nuPorcentajeTC`. It provides the `NU_CUENTA` and `FH_ASIGNACION` for filtering the movement data.
* **`GORAPR.TSCA217_REL_CASO_SIA`**: Used in multiple subqueries (with `LISTAGG`) to gather related SIA case IDs (`cdCasosSIA`), dictamen types (`tpDictamen`), whether the client is PEP (`cdPEP`), and dictamen dates (`fhDictamen`).
* **`GORAPR.TSCA014_CASO`**: Used within the `TSCA217_REL_CASO_SIA` subqueries to link client IDs to case IDs.
* **`GORAPR.TSCA018_DET_CATALOG`**: Used within the `tpDictamen` subquery to translate decision codes.
* **`GORAPR.TSCA034_KYC`**: Used within the `cdPEP` subquery to check for KYC records (indicating PEP status).

**For the second `SELECT` statement (credit card movements, aliased as `MTC`):**

* **`GORAPR.TSCA059_MOV_TC` (aliased as `MTC`)**: This is the primary source for credit card movement data.
* **`GORAPR.TSCA108_CAT_OPER`**: Used in a subquery to translate the `CD_OPERACION` into a human-readable concept (`nbConceptoTC`).
* **`GORAPR.TSCA003_OFICINA`**: Used in a subquery to get the office name (`NB_OFICINA`) based on `CD_OFICINA` for `nbOficina`.
* **`GORAPR.TSCA013_ALERTA`**: Used extensively in subqueries within the `WHERE` clause and for calculating `nuPorcentajeTC`. It provides the `NU_CUENTA` and `FH_ASIGNACION` for filtering the movement data.
* **`GORAPR.TSCA019_MOV_BG`**: Used in subqueries to determine `tpMovimiento` and `nbTpMovimiento`. This seems to be an anomaly, as credit card movements should ideally derive this from their own data, but this query pulls it from `TSCA019_MOV_BG` based on matching `CD_CASO`, `NU_CUENTA`, and `FH_OPERACION` criteria.
* **`GORAPR.TSCA051_ACT_BANXICO`**: Used in the anomalous subqueries to determine `tpMovimiento` and `nbTpMovimiento`.

---

### Variables que Recibe

The query expects the following variables (parameters) for filtering in both parts of the `UNION`:

* **`&CD_CASO`**: The case code.
* **`&CD_ALERTA`**: The alert code.
* **`&CD_SISTEMA`**: The system code.

These parameters are essential for filtering the movement data to a specific case, and for determining the relevant account number and a four-month period (current month of `FH_ASIGNACION` and the three preceding months).

---

### Campos de Salida

The query combines results from both types of movements (`TSCA019_MOV_BG` and `TSCA059_MOV_TC`) and outputs the following fields:

* `cdCaso`: The case ID.
* `nbConceptoTC`: A concatenated string of the operation code and its description. For general banking movements, it has special handling for 'USD' currency and 'T17'/'T20' legends.
* `nuMovimientosTC`: The movement number (for general banking) or reference code (for credit card).
* `imMontoTC`: The movement amount, rounded to two decimal places.
* `cdDivisa`: The currency code.
* `nuPorcentajeTC`: The percentage of the current movement amount relative to the total sum of amounts for the filtered period, rounded to two decimal places. If the sum of amounts is zero, it defaults to 1 to avoid division by zero.
* `tpMovimiento`: The type of movement ('ABONO' or 'CARGO'). For credit card movements, this value is derived from the general banking movements table based on matching criteria.
* `fhOperacion`: The operation date.
* `nbTpMovimiento`: The raw type of movement code ('H' or 'D'). Similar to `tpMovimiento`, for credit card movements, this value is derived from the general banking movements table.
* `nuCuenta`: The account number (for general banking) or contract number (for credit card).
* `nbOficina`: The office code concatenated with the office name.
* `nbDescripcion`: A concatenated description of the movement, including the office name for general banking, or the movement description for credit card.
* `nbTerminal`: The terminal name (for general banking) or an empty string (for credit card).
* `nbHoraOpe`: The operation hour.
* `cdCentro`: The office/center code and name (for general banking) or an empty string (for credit card).
* `nuCuentaBenef`: The beneficiary account number (for general banking) or an empty string (for credit card).
* `nbBeneficiario`: The beneficiary name (for general banking) or an empty string (for credit card).
* `nbActBanxico`: The Banxico activity name (for general banking) or an empty string (for credit card).
* `cdRfc`: The RFC (Mexican tax ID) from general banking movements or an empty string for credit card.
* `nbInstruccion`: The instruction name from general banking movements or an empty string for credit card.
* `cdCliente`: The client ID from general banking movements or an empty string for credit card.
* `stMuestraTT`: The `ST_MUESTRA_TT` flag from general banking movements or an empty string for credit card.
* `cdCasosSIA`: A comma-separated list of related SIA case IDs (derived for general banking movements) or an empty string for credit card.
* `tpDictamen`: A comma-separated list of dictamen types (derived for general banking movements) or an empty string for credit card.
* `cdPEP`: A comma-separated list indicating if the client is PEP for related SIA cases ('SI'/'NO') (derived for general banking movements) or an empty string for credit card.
* `fhDictamen`: A comma-separated list of dictamen dates (derived for general banking movements) or an empty string for credit card.

---

This query provides a detailed overview of movements (both general banking and credit card) related to a specific case and alert, including complex percentage calculations and enriched data from various related tables.