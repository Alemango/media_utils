No problem, let's analyze this SQL query for you.

---

### Tablas de Entrada

Esta query extrae información de las siguientes tablas:

* **`GORAPR.TSCA034_KYC` (alias `KYC`)**: Esta es la tabla principal, que contiene la mayoría de los datos de "Know Your Customer" (KYC).
* **`GORAPR.TSCA063_ACCIONISTA` (alias `ACCIONISTA`)**: Unida a la tabla `KYC` para obtener el objeto social (`txObjetoSocial`). La unión es un `LEFT JOIN` implícito (usando `(+)`), lo que significa que los registros de `KYC` se devolverán incluso si no hay una coincidencia en `ACCIONISTA`.
* **`GORAPR.TSCA068_ACT_KYC` (alias `ACT`)**: Unida a la tabla `KYC` para determinar el riesgo de la actividad económica (`nbRieActividad`). También es un `LEFT JOIN` implícito.
* **`GORAPR.TSCA016_CLIENTE` (alias `T016`)**: Unida a la tabla `KYC` para obtener la actividad económica de Banxico (`nbActEconomica` y parte de `nbOcupacion`). Es un `LEFT JOIN` implícito.
* **`GORAPR.TSCA051_ACT_BANXICO`**: Utilizada en subconsultas para obtener el nombre de la actividad económica de Banxico.
* **`GORAPR.TSCA012_PARAMETRO`**: Utilizada en subconsultas para decodificar códigos en descripciones legibles (e.g., ubicación de operación, estados federales).
* **`GORAPR.TSCA106_PAIS`**: Utilizada en subconsultas para obtener los nombres de países (e.g., país de residencia, nacionalidad, estados federales de transacciones).

---

### Variables que Recibe

La query recibe las siguientes variables como parámetros en la cláusula `WHERE` de la subconsulta interna:

* **`&CD_CASO`**: El código del caso.
* **`&NU_CLIENTE`**: El número del cliente.

Estos valores son esenciales para filtrar los resultados y deben ser proporcionados al ejecutar la consulta.

---

### Campos de Salida

La query devuelve los siguientes campos:

* `cdCaso`
* `nbRegSimplificado`
* `nbActEconomica`
* `nbOcupacion`
* `nbPuestoPEP`
* `nbPEP`
* `nbParentescoPEP`
* `nbPersRel`
* `nbJusOpePesos`
* `nbJusOpeDolares`
* `imMonTotDepositos`
* `nbLocOperar`
* `fhCamAltBajRiesgo`
* `fhAltAltRiesgo`
* `fhUltMovAltBaj`
* `nbOrigenBaja`
* `nbOrigenAlta`
* `nbPaisResidencia`
* `nbNacionalidad`
* `nbJusAperCta`
* `nbProRecursos`
* `nbPriFueIngresos`
* `nbRieActividad`
* `nuTipCliente`
* `nuActEconomica`
* `nuOcupacion`
* `nuRegPais`
* `nuProServicios`
* `nuOpeHabitual`
* `nuIntervinientes`
* `nuSucursal`
* `nuCanCaptacion`
* `nuAntiguedadPuntaje`
* `nuEdad`
* `nuTotal`
* `nbMotRiesgo`
* `txObjetoSocial`
* `imTransInt`
* `cdEntFedIntOri`
* `cdEntFedIntDes`
* `imTransNacional`
* `cdEntFedNalOri`
* `cdEntFedNalDes`
* `imEfectivo`
* `imInstrumento`
* `nbIndRiesgo`

---

¿Necesitas ayuda con otra consulta?